# Reckoner

The `reckoner/behavior` entry supplies DOM-free service and rate editors. Transport is an explicitly supplied dependency. Importing behavior registers no elements and applies no styles.

```typescript
import {
  createServicesBehavior,
  type SettingsTransport,
  type ServicesDocument,
} from "reckoner/behavior";

export async function editServices(
  transport: SettingsTransport<ServicesDocument>,
) {
  const editor = createServicesBehavior({ transport });
  const unsubscribe = editor.subscribe((state) =>
    console.log(state.phase, state.message),
  );
  await editor.initialize();
  editor.setService("wedding", "enabled", true);
  editor.setService("wedding", "rate", "300.00");
  await editor.save();
  unsubscribe();
  editor.dispose();
}
```

Read the initial snapshot from `state`; `subscribe` reports subsequent changes and returns an unsubscribe function. State snapshots are immutable. Raw editable rate strings preserve empty and partly typed values. An empty rate is unset; zero is a configured rate. Validation blocks invalid saves, and valid saves carry the fetched document with `expectedVersion`.

`initialize()` is idempotent. `reload()` explicitly reloads the saved configuration. Failed saves keep the draft; conflicts require a reload before saving again. `dispose()` is idempotent, cancels outstanding work, and ignores late responses. Each editor owns its state and subscriptions independently.

Use `replaceTransport(next)` when credentials change. The editor loads the new calculator before offering `restore()` for unsaved changes belonging to the same calculator. Restoring reconciles the draft against the latest service or factor descriptors. A different calculator never receives the old draft.

The native services, rates, theme and display presentations are available through explicit registration:

```typescript
import { defineAdminElements } from "reckoner/admin";

defineAdminElements();
const editor = document.createElement("reckoner-admin-services");
editor.apiBaseUrl = "https://api.example";
editor.adminToken = token;
document.body.append(editor);
```

Use `<reckoner-admin-rates>` for cost-factor rates. Set credentials with `adminToken`; an initial `admin-token` attribute is consumed and removed on connection. `api-base-url` mirrors `apiBaseUrl`. Changing either reconnects the editor to its service. The bubbling, composed `reckoner-auth-expired` event asks the host to refresh credentials. Disconnect cancels requests and releases subscriptions; remount loads a fresh saved snapshot. The readonly `state` property exposes the shared editor snapshot.

`createThemeBehavior({ transport })` exposes `setValue(property, value)` and draft contrast `state.warnings`; `createDisplayBehavior({ transport })` exposes `setText(field, value)`, `setShowCodeField(value)` and `setVisibleInput(id, value)`. Both use the same lifecycle, save and restoration actions as the service editor. Theme exports include `defaultTheme`, `themeProperties`, `validThemeValue`, `validateTheme`, `safeTheme` and `themeWarnings`; these are DOM-free and can be used by independent presentations. Invalid CSS values are rejected, and plain display text is preserved literally.

The corresponding elements are `<reckoner-admin-theme>` and `<reckoner-admin-display>`. Theme changes preview locally before saving. The theme preview exposes `part="preview"` and applies draft custom properties on that container, so inherited host overrides cannot hide draft changes. Theme and display forms expose `header` and `footer` slots.

`createDiscountsBehavior({ transport })` and `<reckoner-admin-discounts>` edit advance-booking rules, slow-day weekdays and up to 200 discount codes. Actions are `setAdvance`, `setSlowDay`, `setWeekday`, `addCode`, `setCode`, and `removeCode`, plus the common save/reload/lifecycle surface. `addCode()` returns a stable draft row identifier. Percentages and day counts remain raw text until validation. Codes are trimmed and uppercased on save; optional validity dates use `YYYY-MM-DD`. Duplicate codes, reversed ranges and invalid percentages prevent saving. Rule groups use native fieldsets with labelled controls and remove buttons.

`createAvailabilityBehavior({ transport, calendar })` and `<reckoner-admin-availability>` edit the seven weekday flags and up to 365 date exceptions. Supply `createIntlCalendarContext(createTimerScheduler())` or an equivalent injected calendar. Each successful settings response anchors it from the transport's `serverDate` and customer timezone. Actions are `setWeekday`, `addException`, `setException`, and `removeException`, plus the common editor surface. `addException()` returns a stable row identifier; dates remain raw `YYYY-MM-DD` strings and notes are plain text. Validation rejects expired ends, reversed or overlapping ranges, spans above 366 inclusive days, starts beyond 730 days and notes above 100 characters. Expired saved exceptions are omitted on load.

`createLoyaltyBehavior({ transport, codes, scheduler })` and `<reckoner-admin-loyalty>` combine enabled/percentage settings with a separate private code workflow. Supply a `SettingsTransport<LoyaltyDocument>` and `createLoyaltyCodesHttpTransport({ apiBaseUrl, adminToken })` from `reckoner/http`. `state.codes` exposes the paged rows, cursor, search/status filters, raw issue draft, field errors and operation states. Actions are `setEnabled`, `setPercentage`, `setIssue`, `issueCode`, `setSearch`, `setStatus`, `loadMore`, `retryCodes`, and `revokeCode`, with ordinary editor save/reload/restore/lifecycle methods. Pages contain 50 records; search waits 300 ms and never loads every record automatically. Issuance and revocation do not save the versioned settings document.

The native loyalty editor confirms revocation in a labelled modal dialog with Cancel and Confirm revoke. A cancelled dialog sends no mutation. Refresh both dependencies together with `replaceServices(nextSettingsTransport, nextCodesTransport)`; this cancels old work, clears private rows, and offers explicit restoration of an unsaved issue draft only for the same calculator. The native element does this automatically when its token or base URL changes. All user labels and code values render as plain text.

`createLocationsBehavior({ transport, addresses })` and `<reckoner-admin-locations>` edit a resolved base and studio rows. Use `createAdminAddressHttpTransport({ apiBaseUrl, adminToken })` for `addresses`; its provider lookup uses the administrative route. `setAddressQuery(target, text)`, `resolveAddress(target)`, and `selectAddress(target, candidateId)` use target `base` or a studio row identifier. Every row owns an independent cancellable lookup. Editing selected address text clears its coordinates. `addStudio()` returns the stable row identifier and sets `state.lastAddedRowId`; `setStudio(rowId, field, raw)` edits name, fee or enabled status, and `removeStudio(rowId)` disposes that row's lookup. New studio requests omit `id`, allowing the API to assign it. Save stays disabled until addresses and fees are valid, and zero is a valid configured fee. `state.supportsLocations` and `state.supportsStudios` reflect the profession template; unsupported controls are hidden. Refresh both dependencies with `replaceServices(nextSettings, nextAddresses)`.

Each widget has its own shadow root and leaves surrounding layout and margins to the host. Customize `--reckoner-surface`, `--reckoner-ink`, `--reckoner-muted`, `--reckoner-line`, `--reckoner-accent`, `--reckoner-accent-ink`, `--reckoner-danger`, `--reckoner-font-sans`, `--reckoner-font-serif`, `--reckoner-radius`, `--reckoner-space-unit`, and `--reckoner-focus-ring`. Stable parts are `panel`, `heading`, `form`, `control`, `button`, and `error`. Direction inherits from the host; product text is English, and monetary field labels use the calculator currency. Defaults are defined in the bundled styles and require no global stylesheet.

The public quote workflow also runs without a DOM:

```typescript
import {
  createQuoteBehavior,
  createIntlCalendarContext,
  createTimerScheduler,
} from "reckoner/behavior";
import { createQuoteHttpTransport } from "reckoner/http";

const scheduler = createTimerScheduler();
const quote = createQuoteBehavior({
  scheduler,
  calendar: createIntlCalendarContext(scheduler),
  transport: createQuoteHttpTransport({
    apiBaseUrl: "https://api.example",
    publishableKey,
  }),
  initialDraft: { service: "wedding", startTime: "10:00", endTime: "14:00" },
});
const unsubscribe = quote.subscribe((state) => render(state));
render(quote.state);
await quote.initialize();
quote.actions.setFactor("assistant", "1");
// When the consumer unmounts:
unsubscribe();
quote.dispose();
```

`QuoteState` separates initialization from calculation. A result exists only when `calculation.status === "current"`; edits invalidate it synchronously. `actions` exposes `setInput`, `setFactor`, `setLocation`, `removeLocation`, `setDraftCode`, `applyCode`, `setAddressQuery`, `resolveAddress`, `selectAddress`, `showAvailabilityMonth`, `retryAvailability`, `retryInitialization`, and `retry`. Input values stay raw strings. Location actions use stable row identifiers; selecting a current candidate returns the new row identifier. Code keystrokes change only draft text; blur, Enter, or Apply should call `applyCode()`. The behavior deduplicates normalized commits.

Complete inputs calculate after 300 ms without edits. Requests time out after 10 seconds and retry only on an explicit action. Cancellation, input revision, and request generation reject late responses. Refreshed configuration reconciles the current draft; a removed service or studio produces a review notice. Server `Date` headers anchor customer-local dates through a monotonic scheduler, including revalidated 304 responses. Default date is tomorrow; other absent inputs are empty, with empty counts effective zero. Consumers may supply raw `initialDraft` service, date, times, service quantity and factor values; these receive ordinary validation.

Transport operations return `{ promise, cancel }`. `createQuoteHttpTransport` validates explicit API configuration, uses CORS without cookies, refuses redirects, retains instance-local definition ETags, and reports problem details through `TransportFailure`, including `configurationRevision` and `retryAfter`. It uses no persistent browser storage. `createAddressLookupBehavior` and `createMonthAvailabilityBehavior` are independently composable capabilities; dispose them when their owner unmounts. All snapshots are immutable, subscriptions report later changes, and disposal is idempotent.

The native quote uses explicit registration:

```typescript
import { defineQuoteElement } from "reckoner/quote";
defineQuoteElement();
const element = document.createElement("reckoner-quote");
element.apiBaseUrl = "https://api.example";
element.publishableKey = publishableKey;
document.body.append(element);
element.addEventListener("reckoner-quote-change", (event) => {
  console.log((event as CustomEvent).detail.status);
});
```

`publishable-key` and `api-base-url` mirror `publishableKey` and `apiBaseUrl`. Changing either while connected starts a fresh lifetime; disconnected changes send no request. `initialDraft` supplies the raw defaults described above; replacing it also starts a fresh lifetime. The read-only `state` property exposes the current behavior snapshot. Registration is idempotent, importing registers nothing, and disconnect cancels requests, timers and subscriptions. The bubbling, composed `reckoner-quote-change` event carries `{ status }`, with `result` only for a current quote; it carries no credentials.

The quote element exposes `header` and `footer` slots and `panel`, `heading`, `form`, `control`, `button`, `error`, `estimate`, and `total` parts. It uses the same 13 theme custom properties and defaults as the administrative theme editor, including `--reckoner-surface-muted` (default `#F3F7F6`). Host custom properties override stored theme values. `lang` overrides customer locale for formatting; `dir` inherits. Layout follows container width: one column below 768 px and two above it, with all surrounding margins owned by the host.

Stable test hooks are `data-testid="quote-total"` and `data-testid="quote-status"`. Accessible names include `Your estimate`, `Location n`, `Remove location n`, `Find address`, `Matching addresses`, `Apply`, `Retry estimate`, `Retry loading`, `View date availability`, `Previous month`, `Next month`, `Retry availability`, and `Session dates`. Calendar days use ISO date names, suffixed with `, unavailable` where applicable; unavailable dates can still be selected. The day grid has one tab stop with arrow navigation. Field labels come from the template, with `Session date`, `Start time`, `End time`, `Quantity`, `Parking (<currency>)`, `Studio`, `Studio hours`, `Find a location`, and `Discount or loyalty code` for common fields.

The independent Angular presentation is available from `reckoner/angular/quote`, with optional Angular 22.x and TypeScript 6.0.x peers. Importing it does not register custom elements or load the native renderer. The package uses Angular partial compilation; the consuming application's Angular linker completes compilation, as described in the [Angular package format](https://angular.dev/tools/libraries/angular-package-format).

Create one editor per mounted calculator in a component or component-scoped service:

```typescript
import { DestroyRef, inject } from "@angular/core";
import {
  createQuoteEditor,
  ReckonerQuoteViewComponent,
} from "reckoner/angular/quote";
import { createQuoteHttpTransport } from "reckoner/http";

// In the host's component/service injection context; configuration comes from the host.
const editor = createQuoteEditor({
  transport: createQuoteHttpTransport({
    apiBaseUrl,
    publishableKey,
    fetch: globalThis.fetch.bind(globalThis),
  }),
  destroyRef: inject(DestroyRef),
});
```

Import `ReckonerQuoteViewComponent` in the host component's `imports` and use its separate template:

```html
<reckoner-angular-quote
  [state]="editor.state()"
  [actions]="editor.actions"
  lang="fr-CA"
/>
```

`QuoteEditor` exposes readonly `state: Signal<QuoteState>`, `actions: QuoteActions`, and idempotent `dispose()`. The factory initializes once, projects change notifications, and cancels pending work on disposal. `destroyRef` is optional; without it the host must call `dispose()`. Optional `scheduler`, `calendar`, and `initialDraft` have the same defaults and semantics as the shared behavior. Replacing identity or transport requires disposing the previous editor and creating another. The view creates no behavior itself. Theme, composition, and `lang` changes preserve the editor and its draft. `state.dateRange` exposes inclusive selectable customer-local dates, or `null` before anchoring and after disposal.

Angular uses the same CSS custom properties, defaults, responsive layout, accessible names, and stable test hooks documented above. Its component styles are scoped; the host owns surrounding margins and layout. `dir` inherits and `lang` overrides formatting. Add `ReckonerQuoteHeaderDirective` and `ReckonerQuoteFooterDirective` to the host's imports to supply typed composition templates:

```html
<reckoner-angular-quote [state]="editor.state()" [actions]="editor.actions">
  <ng-template reckonerQuoteHeader let-state="state"
    ><p>Your {{ state.definition?.currency }} estimate</p></ng-template
  >
  <ng-template reckonerQuoteFooter let-actions="actions"
    ><button type="button" (click)="actions.setInput('service', '')">
      Choose another service
    </button></ng-template
  >
</reckoner-angular-quote>
```

Both contexts are `QuotePresentationContext { state, actions }`. Header content appears before the form and footer content after the estimate. For a fully custom UI, consume `reckoner/behavior` and render it directly. Presentation-only focus and touched-field state belong to each view; mounting and definition updates never request focus.

Run `npm test`, `npm run typecheck`, and `npm run build` from the private frontend workspace. Build cleans generated artifacts and enforces gzip budgets of 100,000 bytes for the complete reachable native quote entry and 250,000 for admin; measurements are written to `dist/size-report.json`. Run `npm test` from `e2e` for real API browser acceptance tests against the built native and Angular entries.
